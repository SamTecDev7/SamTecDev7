<?php

namespace App\Utilitarios;

class View{

    private static function contentVIew($view){

        $file = __DIR__.'/../../resources/view/'.$view.'.html';
        $check = file_exists($file) ? file_get_contents($file) : '';

        return $check;
    }

    public static function build($view, $var = []){

        $content = self::contentVIew($view);

        $chaves = array_keys($var);
        $chaves = array_map(function($item){
            return '{{'.$item.'}}';
        }, $chaves);

        return str_replace($chaves, array_values($var), $content);
    }

}