<?php

namespace App\Http;

class Request{

    /**
     *@var string
     */
    private $metudoHttp = '';

    /**
     *@var string
     */
    private $uri = '';

    /**
     *@var array
     */
    private $paramentros = [];

    /**
     *@var array
     */
    private $varsPost = [];

    /**
     *@var array
     */
    private $headers = [];

    public function __construct(){
        $this->paramentros = $_GET ?? [];
        $this->varsPost = $_POST ?? [];
        $this->headers = getallheaders();
        $this->metudoHttp = $_SERVER['REQUEST_METHOD'] ?? '';
        $this->uri = $_SERVER['REQUEST_URI'] ?? '';
    }

    public function getMetudoHttp(){
        return $this->metudoHttp;
    }

    public function getUri(){
        return $this->uri;
    }

    public function getHeaders(){
        return $this->headers;
    }

    public function getParamentros(){
        return $this->paramentros;
    }

    public function getVarsPost(){
        return $this->varsPost;
    }
}