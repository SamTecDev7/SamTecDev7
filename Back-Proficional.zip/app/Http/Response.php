<?php

namespace App\Http;

class Response{

    private $httpCode = 200;
    private $headers = [];
    private $contentType = 'text/html';
    private $content;

    public function __construct($httpCode, $content, $contentType = 'text/html'){
        $this->httpCode = $httpCode;
        $this->content = $content;
        $this->ajustContentType($contentType);
    }

    public function ajustContentType($contentType){
        $this->contentType = $contentType;
        $this->adcHeader('Content-Type', $contentType);
    }

    public function adcHeader($key, $value){
        $this->headers[$key] = $value;
    }

    private function enviarHeaders(){
        http_response_code($this->httpCode);

        foreach($this->headers as $key=>$value){
            header($key.': '.$value);
        }
    }

    public function enviarResposta(){
        $this->enviarHeaders();
        
        switch ($this->contentType){
            case 'text/html':
                echo $this->content;
                exit();
        }
    }
}