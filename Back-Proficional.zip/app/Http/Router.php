<?php

namespace App\Http;

use \Closure;
use \Exception;

class Router{

    private $url = '';

    private $prefix = '';

    private $routes = [];

    private $request;

    public function __construct($url){
        $this->request = new Request();
        $this->url = $url;
        $this->ajustarPrefix();
    }

    private function ajustarPrefix(){
        $ajuste = parse_url($this->url);

        $this->prefix = $ajuste['path'] ?? '';
    }

    private function adcRouter($metudo, $rota, $parametros = []){
        foreach($parametros as $key=>$value){
            if($value instanceof Clousure){
                $parametros['controller'] = $value;
                unset($parametros[$key]);
                continue;
            }
        }

        $validarRoute = '/^'.str_replace('/','\/',$rota).'$/';

        $this->routes[$validarRoute][$metudo] = $parametros;

        echo '<pre>';
        print_r($this);
        echo '</pre>'; exit;
    }

    public function get($route, $parametro = []){
        return $this->adcRouter('GET', $route, $parametro);
    }

    private function getUri(){
        $uri = $this->request->getUri();
        $fatiarUri = strlen($this->prefix) ? explode(strtoupper($this->prefix), strtoupper($uri)) : [$uri];
        
        return end($fatiarUri);
    }

    private function getRoute(){
        $uri = $this->getUri();
        $metudoHttp = $this->request->getMetudoHttp();

        foreach($this->routes as $validarRoute=>$metudo){
            if(preg_match($validarRoute, $uri)){
                if($metudo[$metudoHttp]){
                    return $metudo[$metudoHttp];
                }

                throw new Exception('Rota não permitida', 405);
            }
        }

        throw new Exception('O caminho que você está tentando acessar não foi encontrado', 405);
    }

    public function run(){
        try{
            $route = $this->getRoute();

        }catch(Exception $e){
            return new Response($e->getCode(), $e->getMessage());
        }
    }
}