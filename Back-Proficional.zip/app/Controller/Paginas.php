<?php

namespace App\Controller;

use \App\Utilitarios\View;

class Paginas{

    public static function Paginas($title, $content){
        
        return View::build('paginas', [
            'title' => $title,
            'conteudo' => $content
        ]);
    }

}