<?php

namespace App\Controller;

use \App\Utilitarios\View;
use \App\Model\Entity\Buscar;

class Inicio extends Paginas{

    public static function Inicio(){

        $dados = new Buscar;
        
        $content = View::build('Inicio', [
            'nome' => $dados->nome,
            'cidade' => $dados->cidade,
            'profissão' => 'Dev'
        ]);

        return parent::Paginas('Bem vindo', $content);
    }

}