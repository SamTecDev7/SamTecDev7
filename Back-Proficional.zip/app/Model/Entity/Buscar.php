<?php

namespace App\Model\Entity;

class Buscar{

    public $nome = 'Samuel';

    public $cidade = 'Natal';
}